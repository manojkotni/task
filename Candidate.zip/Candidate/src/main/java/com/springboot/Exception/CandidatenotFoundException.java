package com.springboot.Exception;




@SuppressWarnings("serial")
public class CandidatenotFoundException extends Exception {
	
	public CandidatenotFoundException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

 

}
	

 
	 

	    

	

