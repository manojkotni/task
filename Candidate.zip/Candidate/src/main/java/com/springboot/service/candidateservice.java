//package com.springboot.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.model.Candidate;
//import com.springboot.Exception.CandidatenotFoundException;
//import com.springboot.repository.CandidateRepository;
//@Service
//public class candidateservice implements Candidateserives {
//	 @Autowired
//	    private CandidateRepository repository;
//
//	    @Override
//	    public boolean createCandidate(Candidate candidate) throws CandidatenotFoundException{
//	        // TODO Auto-generated method stub
//	        if((repository.findById(candidate.getCandidateName()).isEmpty())) {
//	            repository.save(candidate);
//	            return true;
//	        }else {
//	            throw new CandidatenotFoundException("Candidate Already exists!!");
//	        }
//	       
//	    
//	    }
//}
//
